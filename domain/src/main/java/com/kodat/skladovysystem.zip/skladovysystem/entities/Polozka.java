package com.kodat.skladovysystem.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "polozka")
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Polozka {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;
    protected int mnozstvi;
    @ManyToOne
    @JoinColumn(name="produkt_id")
    protected Produkt produkt;
}
