package com.kodat.skladovysystem.enums;


import jakarta.persistence.Entity;
import jakarta.persistence.Table;

public enum Role {
    ADMIN,
    VEDOUCI_SKLADU,
    SKLADNIK,
    MANAZER
}
